# Load the Rails application.
require_relative 'application'

# obv SO voor rmagick
# config.gem "rmagick",
# :lib => "RMagick" 

# Initialize the Rails application.
Rails.application.initialize!
