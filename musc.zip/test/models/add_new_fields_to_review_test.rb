require 'test_helper'

class AddNewFieldsToReviewTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
