require 'test_helper'

class TrainingTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
