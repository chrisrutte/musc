class HomepagesController < ApplicationController
  layout "homepages"

  def index
  end
end
