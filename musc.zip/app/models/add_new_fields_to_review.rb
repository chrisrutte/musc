class AddNewFieldsToReview < ApplicationRecord
  belongs_to :user
end
