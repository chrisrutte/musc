module TrainingsHelper
end
